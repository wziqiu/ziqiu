<?php

defined('SYSPATH') || exit('Access Denied.');

class Cache_Exception extends BootPHP_Exception {
	
}
