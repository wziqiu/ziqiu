<?php

defined('SYSPATH') || exit('Access Denied.');

/**
 * 数据库异常。
 * @package		BootPHP/数据库
 * @category	异常
 * @author		Tinsh
 * @copyright	(C) 2005-2016 Kilofox Studio
 */
class Database_Exception extends BootPHP_Exception {
	
}
