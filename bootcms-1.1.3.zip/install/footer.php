<hr />
<div id="footer">
	Powered by <strong>BootCMS</strong>, based on <strong>BootPHP</strong> &copy; Kilofox Studio
</div>
</body>
</html>
