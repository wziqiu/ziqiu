<?php

defined('SYSPATH') || exit('Access Denied.');

/**
 * @package BootPHP
 * @category 异常
 * @author Tinsh
 * @copyright (C) 2005-2016 Kilofox Studio
 */
class View_Exception extends BootPHP_Exception {
	
}
