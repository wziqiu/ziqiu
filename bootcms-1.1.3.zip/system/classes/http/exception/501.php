<?php

defined('SYSPATH') || exit('Access Denied.');

class HTTP_Exception_501 extends HTTP_Exception {

	/**
	 * @var integer HTTP 501 Not Implemented
	 */
	protected $_code = 501;

}
