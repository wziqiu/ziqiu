<?php

defined('SYSPATH') || exit('Access Denied.');

class Config extends BootPHP_Config {
	
}
