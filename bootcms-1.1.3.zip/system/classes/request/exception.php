<?php

defined('SYSPATH') || exit('Access Denied.');

/**
 * @package BootPHP
 * @category 异常
 * @author Tinsh
 * @copyright (c) 2009-2011 BootPHP Team
 */
class Request_Exception extends BootPHP_Exception {
	
}
