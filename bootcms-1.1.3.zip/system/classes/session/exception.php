<?php

defined('SYSPATH') || exit('Access Denied.');

/**
 * @package BootPHP
 * @category 异常
 * @author Tinsh
 * @copyright (c) 2009-2011 BootPHP Team
 */
class Session_Exception extends BootPHP_Exception {

	const SESSION_CORRUPT = 1;

}
