<?php

defined('SYSPATH') || exit('Access Denied.');

return array(
	'cookie' => array(
		'encrypted' => false,
	),
);
