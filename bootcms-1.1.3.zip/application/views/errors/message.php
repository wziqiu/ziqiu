<div id="site_content">
	<div id="content">
		<h1><?php echo $message['title']; ?></h1>
		<p><?php echo $message['content']; ?></p>
	</div>
</div>
