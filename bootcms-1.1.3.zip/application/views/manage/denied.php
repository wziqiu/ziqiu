<div class="form-alert" style="margin-bottom: 26px;">
	<h4>拒绝访问</h4>
	<p>您没有足够的权限来查看该页。如果您认为看到这个消息是错误的，请直接联系我们。</p>
</div>
<form action="<?php echo Url::base(); ?>manage/login" method="post">
	<a href="javascript:history.go(-1)" class="login-button">返回</a>
	<input type="submit" class="login-button" value="登录" />
</form>
