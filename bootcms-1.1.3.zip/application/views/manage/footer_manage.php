<div class="spacer"></div>
</section>
<footer id="footer">
	<?php echo Setup::copyright('admin'); ?>
</footer>