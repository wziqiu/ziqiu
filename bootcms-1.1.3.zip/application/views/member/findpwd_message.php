<div id="site_content">
	<div id="sidebar">
		<?php echo $sidebar; ?>
	</div>
	<div id="content">
		<h1>找回密码</h1>
		<p><?php echo $message; ?></p>
	</div>
</div>
