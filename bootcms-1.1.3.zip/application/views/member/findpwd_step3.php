<div id="site_content">
	<div id="sidebar">
		<?php echo $sidebar; ?>
	</div>
	<div id="content">
		<h1>找回密码</h1>
		<p>密码重置信息已经发送到您的电子邮箱中。请登录您的电子邮箱查收邮件。</p>
	</div>
</div>