<?php

defined('SYSPATH') || exit('Access Denied.');
return array(
	'smilies' => array(
		':amatory:' => 'amatory.gif',
		':amaze:' => 'amaze.gif',
		':angry:' => 'angry.gif',
		':awkward:' => 'awkward.gif',
		':blush:' => 'blush.gif',
		':catty:' => 'catty.gif',
		':cheer:' => 'cheer.gif',
		':cool:' => 'cool.gif',
		':cry:' => 'cry.gif',
		':depressed:' => 'depressed.gif',
		':despise:' => 'despise.gif',
		':disappointed:' => 'disappointed.gif',
		':drool:' => 'drool.gif',
		':dumbfounded:' => 'dumbfounded.gif',
		':eek:' => 'eek.gif',
		':flirt:' => 'flirt.gif',
		':giggle:' => 'giggle.gif',
		':grimace:' => 'grimace.gif',
		':grin:' => 'grin.gif',
		':happy:' => 'happy.gif',
		':kiss:' => 'kiss.gif',
		':lost:' => 'lost.gif',
		':sad:' => 'sad.gif',
		':shutup:' => 'shutup.gif',
		':shy:' => 'shy.gif',
		':slapped:' => 'slapped.gif',
		':sleep:' => 'sleep.gif',
		':sorry:' => 'sorry.gif',
		':surprised:' => 'surprised.gif',
		':threat:' => 'threat.gif',
	)
);
