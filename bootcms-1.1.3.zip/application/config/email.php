<?php

defined('SYSPATH') || exit('Access Denied.');
return array(
	'default' => array(
		'method' => 'smtp',
		'html' => '1',
		'smtp_host' => '',
		'smtp_user' => '',
		'smtp_pass' => ''
	)
);
