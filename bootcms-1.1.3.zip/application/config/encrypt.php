<?php

defined('SYSPATH') || exit('Access Denied.');
return array(
	'default' => array(
		'key' => ''
	)
);
